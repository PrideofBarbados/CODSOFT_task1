import streamlit as st
from sklearn.linear_model import LogisticRegression
import pandas as pd
import numpy as np
import pickle

## model pickle file
pickle_in = open('logisticregression.pkl', 'rb')
model = pickle.load(pickle_in)

## dataset
tiatanic_df = pd.read_csv('tested.csv')

 

##App creation
st.title('Tiatanic survival prediction')

##inputing the x variable
Pclass = st.selectbox("Passenger's Class:", tiatanic_df['Pclass'].unique())
Sex =st.selectbox("Passenger's Gender", tiatanic_df['Sex'].unique())
if Sex=='male':
    Sex=0
else:
    Sex=1

Age = st.selectbox("Passenger's Age")
SibSp = st.selectbox(" Number of Passenger's Siblings/Spouse:", tiatanic_df['SibSp'].unique())
Parch= st.selectbox("Number of Passenger's Parent/childern:", tiatanic_df['Parch'].unique())
Embarked = st.selectbox("Passenger's Place of Embarkation ", ['Cherbourg', 'Queenstown', 'Southampton'])
if Embarked == 'Southampton':
    Embarked=0
elif Embarked== 'Cherbourg':
    Embarked=1
else:
    Embarked =2
## prediction
result = model.predict([[Pclass, Sex, Age, SibSp,Parch, Embarked]])

if st.button('Predict'):
    if result==1:
        st.write('Passenger  survived')
    else:
        st.write('Sorry passenger did not survive')

   


   